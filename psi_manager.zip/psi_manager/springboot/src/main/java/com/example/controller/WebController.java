package com.example.controller;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.lang.Dict;
import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.example.common.Result;
import com.example.common.enums.LogType;
import com.example.common.enums.ResultCodeEnum;
import com.example.common.enums.RoleEnum;
import com.example.entity.Account;
import com.example.entity.Goods;
import com.example.entity.Sale;
import com.example.entity.Stock;
import com.example.exception.CustomException;
import com.example.service.*;
import com.example.utils.ValidateCodeCache;
import com.example.utils.ValidateCodeProperties;
import com.wf.captcha.GifCaptcha;
import com.wf.captcha.SpecCaptcha;
import com.wf.captcha.base.Captcha;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 基础前端接口
 */
@RestController
public class WebController {

    @Resource
    private AdminService adminService;
    @Resource
    private StaffService staffService;
    @Resource
    private SaleService saleService;

    @Resource
    private GoodsService goodsService;

    @Resource
    private StockService stockService;

    @GetMapping("/")
    public Result hello() {
        return Result.success("访问成功");
    }

    @GetMapping("/validateCode")
    public void getValidateCode(HttpServletRequest request, HttpServletResponse response) {
        // 生成验证码
        ValidateCodeProperties code = new ValidateCodeProperties();
        setHeader(response, code.getType());
        Captcha captcha = createCaptcha(code);
        // 存储验证码到缓存
        ValidateCodeCache.setCache(request.getParameter("key"), captcha.text().toLowerCase());
        try {
            captcha.out(response.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
            throw new CustomException(ResultCodeEnum.VALIDATE_CODE_ERROR);
        }
    }


    /**
     * 登录
     */
    @PostMapping("/login")
    public Result login(@RequestBody Account account) {
        if (ObjectUtil.isEmpty(account.getUsername()) || ObjectUtil.isEmpty(account.getPassword())
                || ObjectUtil.isEmpty(account.getRole()) || ObjectUtil.isEmpty(account.getCode())
                || ObjectUtil.isEmpty(account.getKey())) {
            return Result.error(ResultCodeEnum.PARAM_LOST_ERROR);
        }
        boolean validate = ValidateCodeCache.validateCode(account.getKey(), account.getCode());
        if (!validate) {
            return Result.error(ResultCodeEnum.VALIDATE_CODE_ERROR);
        }
        ValidateCodeCache.removeCache(account.getKey(), account.getCode());
        if (RoleEnum.ADMIN.name().equals(account.getRole())) {
            account = adminService.login(account);
        } else if (RoleEnum.STAFF.name().equals(account.getRole())) {
            account = staffService.login(account);
        }
        LogsService.recordLog(account.getUsername() + "登录系统", LogType.LOGIN.getValue(), account.getUsername());
        return Result.success(account);
    }

    /**
     * 注册
     */
    @PostMapping("/register")
    public Result register(@RequestBody Account account) {
        if (StrUtil.isBlank(account.getUsername()) || StrUtil.isBlank(account.getPassword())
                || ObjectUtil.isEmpty(account.getRole())) {
            return Result.error(ResultCodeEnum.PARAM_LOST_ERROR);
        }
        if (RoleEnum.STAFF.name().equals(account.getRole())) {
            staffService.register(account);
        }
        LogsService.recordLog(account.getUsername() + "注册账号", LogType.REGISTER.getValue(), account.getUsername());
        return Result.success();
    }

    /**
     * 修改密码
     */
    @PutMapping("/updatePassword")
    public Result updatePassword(@RequestBody Account account) {
        if (StrUtil.isBlank(account.getUsername()) || StrUtil.isBlank(account.getPassword())
                || ObjectUtil.isEmpty(account.getNewPassword())) {
            return Result.error(ResultCodeEnum.PARAM_LOST_ERROR);
        }
        if (RoleEnum.ADMIN.name().equals(account.getRole())) {
            adminService.updatePassword(account);
        } else if (RoleEnum.STAFF.name().equals(account.getRole())) {
            staffService.updatePassword(account);
        }
        return Result.success();
    }

    @GetMapping("/countData")
    public Result getCountData() {
        List<Goods> goodsList = goodsService.selectAll(null);
        List<Stock> stockList = stockService.selectAll(null);
        List<Sale> saleList = saleService.selectAll(null);
        Integer store = goodsList.stream().map(Goods::getNum).reduce(Integer::sum).orElse(0);
        Double money = goodsList.stream().map(goods -> goods.getPrice() * goods.getNum()).reduce(Double::sum).orElse(0D);
        Integer stock = stockList.stream().map(Stock::getNum).reduce(Integer::sum).orElse(0);
        Integer sale = saleList.stream().map(Sale::getNum).reduce(Integer::sum).orElse(0);

        Dict dict = Dict.create();
        dict.set("store", store).set("money", money).set("stock", stock).set("sale", sale);
        return Result.success(dict);
    }

    /**
     * 获得销售数据
     */
    @GetMapping("/saleData")
    public Result getSaleData() {
        Date today = new Date();
        List<DateTime> dateTimeList = DateUtil.rangeToList(DateUtil.offsetDay(today, -7), DateUtil.offsetDay(today, -1), DateField.DAY_OF_YEAR);
        List<String> dateList = dateTimeList.stream().map(DateUtil::formatDate).sorted(Comparator.naturalOrder()).collect(Collectors.toList());
        List<Dict> resList = new ArrayList<>();
        for (String date : dateList) {
            Sale sale = new Sale();
            sale.setTime(date);
            List<Sale> sales = saleService.selectAll(sale);
            Double total = sales.stream().map(Sale::getTotal).reduce(Double::sum).orElse(0D);
            Dict dict = Dict.create();
            dict.set("name", date).set("value", total);
            resList.add(dict);
        }
        return Result.success(resList);
    }

    @GetMapping("/goodsStoreData")
    public Result getGoodsStoreData() {
        List<Goods> goodsList = goodsService.selectAll(null);
        Set<String> nameSet = goodsList.stream().map(Goods::getName).collect(Collectors.toSet());
        List<Dict> resList = new ArrayList<>();
        for (String name : nameSet) {
            Integer sum = goodsList.stream().filter(goods -> goods.getName().equals(name)).map(Goods::getNum).reduce(Integer::sum).orElse(0);
            Dict dict = Dict.create();
            dict.set("name", name).set("value", sum);
            resList.add(dict);
        }
        return Result.success(resList);
    }


    /**
     * 创建验证码
     */
    private Captcha createCaptcha(ValidateCodeProperties code) {
        Captcha captcha = null;
        if ("gif".equalsIgnoreCase(code.getType())) {
            captcha = new GifCaptcha(code.getWidth(), code.getHeight(), code.getLength());
        } else {
            captcha = new SpecCaptcha(code.getWidth(), code.getHeight(), code.getLength());
        }
        captcha.setCharType(code.getCharType());

        return captcha;
    }

    /**
     * 设置验证码返回头
     */
    private void setHeader(HttpServletResponse response, String type) {
        if ("gif".equalsIgnoreCase(type)) {
            response.setContentType(MediaType.IMAGE_GIF_VALUE);
        } else {
            response.setContentType(MediaType.IMAGE_PNG_VALUE);
        }
        response.setHeader(HttpHeaders.PRAGMA, "No-cache");
        response.setHeader(HttpHeaders.CACHE_CONTROL, "no-cache");
        response.setDateHeader(HttpHeaders.EXPIRES, 0L);
    }

}
